
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
import jwt, time

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = "super_secret"
ADMIN_EMAIL = "admin@qubamind.ai"
ADMIN_PASS = "admin123"

def create_token(email):
    payload = {"email": email, "exp": time.time() + 86400}
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")

def verify_token(token):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        return payload["email"] == ADMIN_EMAIL
    except:
        return False

@app.post("/login")
async def login(request: Request):
    data = await request.json()
    if data["email"] == ADMIN_EMAIL and data["password"] == ADMIN_PASS:
        token = create_token(data["email"])
        return {"token": token}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/verify-token")
def verify(request: Request):
    token = request.headers.get("Authorization")
    if token and verify_token(token):
        return {"status": "valid"}
    raise HTTPException(status_code=401, detail="Invalid token")

@app.post("/command")
async def command(request: Request):
    token = request.headers.get("Authorization")
    if not verify_token(token):
        raise HTTPException(status_code=401, detail="Unauthorized")
    data = await request.json()
    cmd = data.get("command", "").lower()
    if "status" in cmd:
        return {"response": "🟢 System is live and operational"}
    elif "pause" in cmd:
        return {"response": "⏸️ Bot paused"}
    elif "log" in cmd:
        return {"response": "📄 Logs fetched"}
    return {"response": "🤖 Unknown command received."}

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
