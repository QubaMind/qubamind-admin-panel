from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"status": "QubaMind Panel is Running ✅"}

@app.post("/command")
async def command(request: Request):
    data = await request.json()
    cmd = data.get("command", "").lower()
    if "pause bot" in cmd:
        return {"response": "⏸️ Instagram bot paused for 3 hours."}
    elif "show status" in cmd:
        return {"response": "🧠 QubaMind Panel is healthy and live!"}
    elif "add feature" in cmd:
        return {"response": f"🔧 New feature added: {cmd.replace('add feature', '').strip()}"}
    else:
        return {"response": "🤖 Command received: " + cmd}
