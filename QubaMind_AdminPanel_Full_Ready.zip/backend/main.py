
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import os

app = FastAPI()

@app.get("/status")
def read_root():
    return {"status": "QubaMind Panel is Running ✅"}

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
